package com.example.map_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ToggleButton;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, GoogleMap.OnMapClickListener, GoogleMap.OnMapLongClickListener {

     private ListView lista;

    GoogleMap mMap;
    ArrayAdapter<String>adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lista= findViewById(R.id.lsLista);
        adapter=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item);
        lista.setAdapter(adapter);

        SupportMapFragment mapFragment= (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap=googleMap;
        this.mMap.setOnMapClickListener(this);
        this.mMap.setOnMapLongClickListener(this);

        LatLng ecuador=new LatLng(-0.2298500,-78.5249500);
         mMap.addMarker(new MarkerOptions().position(ecuador).title("Ecuador"));
         mMap.moveCamera(CameraUpdateFactory.newLatLng(ecuador));

    }

    @Override
    public void onMapClick(@NonNull LatLng latLng) {
        String latitud=String.valueOf(latLng.latitude);
        String longitud=String.valueOf(latLng.longitude);
        String campos=" latitud: "+ latitud;
        String campos2=" logitud"+longitud;
        adapter.add(campos);
        adapter.add(campos2);
        adapter.notifyDataSetChanged();

        mMap.clear();
        LatLng ecuador=new LatLng(latLng.latitude,latLng.longitude);
        mMap.addMarker(new MarkerOptions().position(ecuador).title(""));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(ecuador));

    }

    @Override
    public void onMapLongClick(@NonNull LatLng latLng) {
        String latitud=String.valueOf(latLng.latitude);
        String longitud=String.valueOf(latLng.longitude);
        String campos=" latitud: "+ latitud;
        String campos2=" logitud"+longitud;
        adapter.add(campos);
        adapter.add(campos2);
        adapter.notifyDataSetChanged();

        mMap.clear();
        LatLng ecuador=new LatLng(latLng.latitude,latLng.longitude);
        mMap.addMarker(new MarkerOptions().position(ecuador).title(""));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(ecuador));


    }
}